print("Enter a shape, either a circle, square or rectangle")
shape = input(" ")
pi = 3.142
if(shape == square) :
  side = float(input("Enter the side of the square:"))
  Area = side * side
print("The area of the square is: ", Area)

else if(shape == circle) :
 radius = float(input("Enter the radius of the circle:"))
pi = 3.142
Area = pi * (radius * 2)
print("The area of the circle is:", Area)

else if(shape == rectangle) :
 length = float(input("Enter the length of the rectangle: "))
width = float(input("Enter the width of the rectangle: "))
Area = length * width
print("The area of the rectangle is: ", Area)

else:
print("Invalid input")



