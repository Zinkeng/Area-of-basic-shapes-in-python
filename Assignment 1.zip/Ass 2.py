print("Code to calculate the area of a cirle")
radius=float(input("Enter the radius of the circle:"))
pi = 3.142
Area = pi * (radius*2)
print ("The area of the circle is:", Area)