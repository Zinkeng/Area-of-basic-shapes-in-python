print ("Code to calculate the area of a rectangle in python")
length = float(input("Enter the length of the rectangle: "))
width= float(input("Enter the width of the rectangle: "))
Area = length * width
print ("The area of the rectangle is: ", Area)



