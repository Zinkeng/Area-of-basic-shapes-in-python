print("A program to calculate the area of a square")
side=float(input("Enter the side of the square:"))
Area = side * side
print("The area of the square is: ",Area)